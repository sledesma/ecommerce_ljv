<?php

function sumar($numero1, $numero2) {
    return $numero1 + $numero2;
}