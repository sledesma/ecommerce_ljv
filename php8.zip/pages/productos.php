 
		<div class="container">
			<section id="page">
				<div class="cat-product">
	<div class="w_content">
		<div class="women">
			<a href="#">
				<h4>Categoria #1 - <span>4449 items</span></h4>
			</a>
			<ul class="w_nav">
				<li>Ordernar por: </li>
				<li><a class="active" href="#">Más recientes</a></li> |
				<li><a href="#">Menor precio</li> |
				<li><a href="#">Mayor precio</a></li> 
				<div class="clearfix"></div>	
			</ul>
			<div class="clearfix"></div>	
		</div>
	</div>
	<!-- grids_of_4 -->
	<div class="grid-product">
		<!-- Producto #1 -->
		<div class="product-grid">
			<div class="content_box">
				<a href="producto.php">
					<div class="left-grid-view grid-view-left">
						<img src="images/productos/P001.jpg" class="img-responsive watch-right" alt=""/>
					</div>
				</a>
				<h4><a href="#">Duis autem</a></h4>
				<p>It is a long established fact that a reader</p>
				<span>$499</span>
			</div>
		</div>
		<!-- Producto #2 -->
		<div class="product-grid">
			<div class="content_box">
				<a href="producto.php">
					<div class="left-grid-view grid-view-left">
						<img src="images/productos/P002.jpg" class="img-responsive watch-right" alt=""/>
					</div>
				</a>
				<h4><a href="#">Duis autem</a></h4>
				<p>It is a long established fact that a reader</p>
				<span>$499</span>
			</div>
		</div>
		<!-- Producto #3 -->
		<div class="product-grid">
			<div class="content_box">
				<a href="producto.php">
					<div class="left-grid-view grid-view-left">
						<img src="images/productos/P003.jpg" class="img-responsive watch-right" alt=""/>
					</div>
				</a>
				<h4><a href="#">Duis autem</a></h4>
				<p>It is a long established fact that a reader</p>
				<span>$499</span>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
			</section>
			<div class="clearfix"></div>
		</div>


		 